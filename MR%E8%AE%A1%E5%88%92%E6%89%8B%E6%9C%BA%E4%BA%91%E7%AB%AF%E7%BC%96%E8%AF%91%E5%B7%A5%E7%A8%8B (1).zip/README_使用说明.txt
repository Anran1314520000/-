MR计划离线 Android 工程

功能：
- 将原始倒计时网页打包进 Android WebView。
- HTML、CSS、JavaScript 全部内置在 APK 中。
- AndroidManifest.xml 没有申请 INTERNET 权限，因此应用本身不联网。
- 目标时间沿用原代码：设备本地时区的 2026-12-31 23:59:00。
- 包名：com.mrplan.offline；版本：0.01。

如何生成 APK：
1. 在电脑安装 Android Studio（建议较新版本）和 Android SDK Platform 35。
2. 解压本工程，在 Android Studio 中选择 Open，打开解压后的 MR计划离线APK工程 文件夹。
3. 等待 Gradle 同步完成。
4. 菜单 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常会生成在 app/build/outputs/apk/debug/app-debug.apk。
6. 将 APK 传到 Android 手机上安装；若系统提示，允许该文件管理器安装未知来源应用。

说明：
当前执行环境没有 Android SDK / Gradle 构建工具，因此这里提供的是可导入 Android Studio 的完整工程源文件，而不是已经编译好的 APK。首次构建通常需要联网下载 Android Gradle 插件及 SDK；构建完成后，应用运行不需要网络。
