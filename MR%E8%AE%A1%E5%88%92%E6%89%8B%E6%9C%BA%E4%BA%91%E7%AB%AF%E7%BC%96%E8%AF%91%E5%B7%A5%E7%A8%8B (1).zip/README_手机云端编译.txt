MR计划：手机云端编译 APK 指南

本工程新增 GitHub Actions 自动构建配置。你不需要电脑，但需要手机浏览器和 GitHub 账号；GitHub 会在云端编译 APK。

操作概要：
1. 在手机浏览器打开 https://github.com/ 并登录/注册。
2. 创建一个新的公开仓库（Repository），名称可填 MRPlanOffline。
3. 将本 ZIP 解压到手机。如果手机不方便解压，可使用支持 ZIP 的文件管理器。
4. 在 GitHub 仓库页面选择 Add file > Upload files，把解压后的工程文件和隐藏目录 .github 一起上传到 main 分支并提交。注意：必须上传 .github/workflows/build-apk.yml；若手机上传界面不显示隐藏目录，需使用 GitHub 网页创建该文件，路径填写 .github/workflows/build-apk.yml，内容来自压缩包中的同名文件。
5. 上传并提交后，打开仓库顶部的 Actions 页面，进入 “Build MR Plan APK” 工作流，查看最新运行状态。
6. 运行成功后打开该次工作流运行记录，页面底部 Artifacts 区域下载 MR-plan-debug-apk。下载的 ZIP 解压后，其中 app-debug.apk 就是安装包。
7. Android 若阻止安装，请只对你信任的下载来源允许“安装未知应用”。

注意：
- GitHub 云端构建首次会下载 Gradle 和 Android SDK，所以构建过程需要网络。
- 生成的 APK 本身没有申请 INTERNET 权限，运行时不需要网络。
- GitHub 仓库若设为公开，上传的源代码会公开；不要上传个人隐私。你也可以使用私有仓库，但需确认账号当前可用的 Actions 额度/权限。
- 此包是可构建工程，不是已经编译好的 APK。
